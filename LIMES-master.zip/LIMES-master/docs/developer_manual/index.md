# LIMES 1.0 Developer Manual

## Introduction

This short manual is intended for developers who want to extend LIMES 1.0 and/or include it into their own software products. It aims to deliver an overview of the architecture underlying our framework, explain the core concepts and give developers entry points into the java docs for further reading.
