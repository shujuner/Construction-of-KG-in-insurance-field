package org.aksw.limes.core.io.cache;

/**
 * Not yet implemented. Will be an elaborate cache for very large data sets
 * that do not fit in memory.
 *
 * @author Axel-C. Ngonga Ngomo (ngonga@informatik.uni-leipzig.de)
 * @author Mohamed Sherif (sherif@informatik.uni-leipzig.de)
 * @version Nov 23, 2015
 */
public class FileCache {

}
