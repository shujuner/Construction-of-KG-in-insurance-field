package org.aksw.limes.core.ml.algorithm;

public class MLParameter {
    
   
    

}
