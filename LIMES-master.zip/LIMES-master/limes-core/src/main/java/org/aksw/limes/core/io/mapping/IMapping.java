package org.aksw.limes.core.io.mapping;

import java.io.Serializable;

/**
 * @author Mohamed Sherif {@literal <}sherif {@literal @} informatik.uni-leipzig.de{@literal >}
 * @version Nov 12, 2015
 */
public interface IMapping extends Serializable{

}
