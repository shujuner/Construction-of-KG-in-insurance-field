package org.aksw.limes.core.io.parser;


/**
 * @author Mohamed Sherif {@literal <}sherif {@literal @} informatik.uni-leipzig.de{@literal >}
 * @version Nov 12, 2015
 */
public interface IParser {

    boolean isAtomic();

}
