package org.aksw.limes.core.io.cache;

/**
 * @author Mohamed Sherif (sherif@informatik.uni-leipzig.de)
 * @version Nov 25, 2015
 */
public interface ICache {

}
