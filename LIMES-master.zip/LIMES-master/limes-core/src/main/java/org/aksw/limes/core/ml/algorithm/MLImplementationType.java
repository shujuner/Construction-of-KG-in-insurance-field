package org.aksw.limes.core.ml.algorithm;

/**
 * @author Tommaso Soru (tsoru@informatik.uni-leipzig.de)
 *
 */
public enum MLImplementationType {

    SUPERVISED_ACTIVE, SUPERVISED_BATCH, UNSUPERVISED;

}
