package org.aksw.limes.core.util;

public interface Clonable<T> {
    public T clone();
}