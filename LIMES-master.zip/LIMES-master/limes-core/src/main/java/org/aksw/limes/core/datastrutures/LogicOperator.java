package org.aksw.limes.core.datastrutures;

public enum LogicOperator {
    AND, OR, MINUS, XOR
}
