package org.aksw.limes.core.measures.measure;

/**
 * Implements the measure abstract class.
 *
 * @author Kleanthi Georgala {@literal <}georgala {@literal @}
 *         informatik.uni-leipzig.de{@literal >}
 * @version 1.0
 */
public abstract class AMeasure implements IMeasure {

}
