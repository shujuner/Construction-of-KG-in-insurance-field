package org.aksw.limes.core.io.config.writer;

import java.io.IOException;

import org.aksw.limes.core.io.config.Configuration;

/**
 * @author Mohamed Sherif (sherif@informatik.uni-leipzig.de)
 * @version Nov 12, 2015
 */
public class XMLConfigurationWriter implements IConfigurationWriter {

    @Override
    public void write(Configuration configuration, String outputFile,
                      String format) throws IOException {
        // TODO Auto-generated method stub

    }

    @Override
    public void write(Configuration configuration, String outputFile)
            throws IOException {
        // TODO Auto-generated method stub

    }

}
