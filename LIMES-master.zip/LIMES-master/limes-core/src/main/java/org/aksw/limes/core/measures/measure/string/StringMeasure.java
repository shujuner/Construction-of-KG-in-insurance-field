package org.aksw.limes.core.measures.measure.string;

import org.aksw.limes.core.measures.measure.AMeasure;

public abstract class StringMeasure extends AMeasure implements IStringMeasure {

}
