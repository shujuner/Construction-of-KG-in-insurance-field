package org.aksw.limes.core.controller;


/**
 * @author Kevin Dreßler
 * @version %I%, %G%
 * @since 1.0
 */
public interface IPipeline {

}
